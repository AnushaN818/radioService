package me.pgb.a2021_03_26_backgroundService.models;

public class RadioStation {
    private String streamLink;
    private String name;
    private String country;

    public RadioStation(String streamLink, String name, String country){
        this.streamLink = streamLink;
        this.name = name;
        this.country = country;
    }

    public String getStreamLink() {return streamLink;}

    public String getName() {return name;}

    public String getCountry() {return country;}

}
