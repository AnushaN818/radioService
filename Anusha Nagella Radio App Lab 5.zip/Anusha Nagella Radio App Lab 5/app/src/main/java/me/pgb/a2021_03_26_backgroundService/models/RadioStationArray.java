package me.pgb.a2021_03_26_backgroundService.models;

public class RadioStationArray {
    private static String[] stringList;



    public static RadioStation[] radioStations = {
            new RadioStation("http://stream.whus.org:8000/whusfm","WHUS", "USA"),
            new RadioStation("http://s2.free-shoutcast.com:18252/;/","Disco Rumba 95.4 FM","USA"),
            new RadioStation("http://playerservices.streamtheworld.com/api/livestream-redirect/SAM03AAC20.mp3","Balkan Radio - North America ", "USA"),
            new RadioStation("http://54.38.43.201:8039/stream-192kmp3-BaySmoothJazz","Bay Smooth Jazz","USA")
    };

    public static String[] getArrayOfRadioLinks(){
        stringList = new String[radioStations.length];

        for (int i=0; i<radioStations.length; i++){
            stringList[i] = radioStations[i].getStreamLink();
        }
        return stringList;
    }

    public static String[] getArrayOfRadioNames(){
        stringList = new String[radioStations.length];

        for (int i = 0; i < radioStations.length; i++){
            stringList[i] = radioStations[i].getName();
        }

        return stringList;
    }

}
