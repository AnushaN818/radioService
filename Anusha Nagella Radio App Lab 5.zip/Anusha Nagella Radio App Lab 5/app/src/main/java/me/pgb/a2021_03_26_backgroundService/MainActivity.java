package me.pgb.a2021_03_26_backgroundService;

import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.os.Handler;
import android.os.HandlerThread;
import android.util.Log;
import android.view.View;

import android.view.Menu;
import android.view.MenuItem;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;

import java.io.IOException;

import me.pgb.a2021_03_26_backgroundService.models.RadioStationArray;

public class MainActivity extends AppCompatActivity {

    private final String TAG = "MAIN";
    private MediaPlayer mediaPlayer;
    private static String url = "http://stream.whus.org:8000/whusfm";
    private Button internetRadioButton;
    private boolean radioOn;
    private boolean radioWasOnBefore;
    private RadioService mService;
    private boolean mBound = false;
    private Spinner spinner;
    private static String[] station;
    private static String[] links;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        spinner = findViewById(R.id.spinner);
        station = RadioStationArray.getArrayOfRadioNames();
        links = RadioStationArray.getArrayOfRadioLinks();

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, station);


        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener()

        {
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id)
            {
                String selectedStation= parent.getItemAtPosition(position).toString();
                radioOn = false; //this is going to turn off the radio
                    internetRadioButton.setText("Turn Radio On");
                    if (mediaPlayer.isPlaying()) {
                        Log.i(TAG, "Turning on radio" );
                        radioWasOnBefore = true;
                    }
                    mediaPlayer.pause();
                    url = links[position]; //this is what actually switches stations

                }


            public void onNothingSelected(AdapterView<?> parent)
            {

            }
        });


        radioOn = false;
        radioWasOnBefore = false;
        mediaPlayer = new MediaPlayer();
        internetRadioButton = findViewById(R.id.radio_button);
        internetRadioButton.setOnClickListener(new View.OnClickListener() {

           @Override
            public void onClick(View view) {

                if (radioOn) {
                    radioOn = false;
                    internetRadioButton.setText("Turn Radio Om");
                    if (mediaPlayer.isPlaying()) {
                        Log.i(TAG, "Radio is playing then turning off " );
                        radioWasOnBefore = true;
                    }
                    mediaPlayer.pause();
                } else {
                    radioOn = true;
                    internetRadioButton.setText("Turn Radio Off");
                    if (!mediaPlayer.isPlaying()) {
                        if (radioWasOnBefore) {
                            mediaPlayer.release();
                            mediaPlayer = new MediaPlayer();
                        }
                        radioSetup(mediaPlayer, url);
                        mediaPlayer.prepareAsync();
                    }
                }

            }
        });
    }



    public void radioSetup(MediaPlayer mediaPlayer, String radio_url) {

        mediaPlayer.setAudioAttributes(
                new AudioAttributes.Builder()
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .build()
        );

        mediaPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            @Override
            public void onPrepared(MediaPlayer mp) {
                Log.i(TAG, "onPrepared" );
                mediaPlayer.start();
            }
        });

        mediaPlayer.setOnErrorListener(new MediaPlayer.OnErrorListener() {
            @Override
            public boolean onError(MediaPlayer mp, int val, int extra) {
                Log.i(TAG, "onError: " + String.valueOf(val).toString());
                return false;
            }
        });

        mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                Log.i(TAG, "onCompletion" );
                mediaPlayer.reset();
            }
        });

        try {
            mediaPlayer.setDataSource(radio_url);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (mediaPlayer != null) {
            mediaPlayer.release();
        }
        mediaPlayer = null;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    private void setUpMediaPlayer() {
        Handler handler = null;

        HandlerThread handlerThread = new HandlerThread("media player") {
            @Override
            public void onLooperPrepared() {
                Log.i(TAG, "onLooperPrepared");

            }
        };

    }
}